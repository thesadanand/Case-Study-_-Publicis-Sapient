package com.ps.ps;

import junit.framework.Test;

class PsApplicationTests {

	@org.junit.Test
	//test for valid end points
	public void testRestEndPoints() {
		
	}
	
	@org.junit.Test
	//test for search operations by id
	public void testSearchbyId() {
		
	}
	
	@org.junit.Test
	//test for search operations by color
	public void testSearchByColor() {
	
	}
	
	@org.junit.Test
	//test for search operations by size
	public void testSearchBySize() {
	}
	
	@org.junit.Test
	//test for search operations by seller
	public void testSearchBySeller() {
	
	}
}