package com.ps.ps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class PsApplication {
	
	/*@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}*/

	public static void main(String[] args) {
		SpringApplication.run(PsApplication.class, args);
	}
}
