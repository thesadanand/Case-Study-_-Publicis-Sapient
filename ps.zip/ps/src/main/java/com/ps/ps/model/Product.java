package com.ps.ps.model;

public class Product {

	private int productId;
	private int	brandId;
	private int sellerId;
	private int price;
	//TODO: enums will be better choice
	private String colour;
	//TODO: enums will be better choice
	private String size;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getBrandId() {
		return brandId;
	}
	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}
	public int getSellerId() {
		return sellerId;
	}
	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", brandId=" + brandId + ", sellerId=" + sellerId + ", price="
				+ price + ", colour=" + colour + ", size=" + size + "]";
	}
}
