package com.ps.ps.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ps.ps.model.Product;

@RestController
@RequestMapping("/search")
public class PSController {

	/*@Autowired
	RestTemplate restTemplate;
	*/
	
	//http://localhost:8080/PsApplication/search/p123
	@RequestMapping(path="/{pid}" ,method = RequestMethod.GET)
	public List<Product> search(@PathVariable("pid") String pid){
		//DOA layer call it will return the list of products having for a given product it;
		/* SELECT * 
		   FROM FACT_TABLE
		   WHERE PRODCUT.ID = 'PID';
		 */
		return Arrays.asList(new Product(),new Product(),new Product());
	}

	//http://localhost:8080/PsApplication/search/groupby/{pid}/{gby}
	@RequestMapping(path = "/search/groupby/{pid}/{pid}", method = RequestMethod.GET)
	public List<Product> groupBySearch(@PathVariable int pid, @PathVariable String groupBy) throws Exception{
		switch(groupBy.toLowerCase()) {
		case "brand":
			// SELECT count(1) FROM FACT_TABLE WHERE PRODUCT-ID = 'pid' GROUPBY BRAND_ID;
			return Arrays.asList(new Product(),new Product(),new Product());
		case "price":
			// SELECT count(1) FROM FACT_TABLE WHERE PRODUCT-ID = 'pid' GROUPBY PRICE;
			return Arrays.asList(new Product(),new Product(),new Product());
		case "size":
			// SELECT count(1) FROM FACT_TABLE WHERE PRODUCT-ID = 'pid' GROUPBY 'size';
			return Arrays.asList(new Product(),new Product(),new Product());
		case "seller":
			// SELECT count(1) FROM FACT_TABLE WHERE PRODUCT-ID = 'pid' GROUPBY SELLER-ID;
			return Arrays.asList(new Product(),new Product(),new Product());
		default:
			throw new Exception("invalid query param");
		}
	}
}